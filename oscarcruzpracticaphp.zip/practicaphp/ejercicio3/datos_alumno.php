<?php
if (isset($_REQUEST['enviadatos']))
{
    $nombre=$_REQUEST['nombre'];
    $telefono=$_REQUEST['telefono'];
    $ensenianza=$_REQUEST['ensenianza'];
    $matriculado=$_REQUEST['matriculado'];
    $tipodatos=$_REQUEST['datos'];
    $datos="El alumno $nombre, con teléfono $telefono, ";
}
if ($matriculado)
{
    $datos .= "figura como matriculado";
}
else
{
    $datos .= "figura como no matriculado";
}
$datos .= " en $ensenianza.";

if ($tipodatos == "pantalla")
{
    echo $datos;
}

if ($tipodatos == "txt")
{
    $nombrearchivo="datos.txt";
    $archivo=fopen($nombrearchivo, "w");
    fwrite($archivo, $datos);
    fclose($archivo);
    echo "<a href=./mostrardatos.php>Mostrar Datos</a>";
}
?>