<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Ejercicio 1</title>
    <link rel="stylesheet" href="ejerciciouno.css">
</head>
<body>
    <fieldset>
        <legend>Formulario</legend>
        <form action="ejercicio1.php">
            <p>Escriba el alto y el ancho (0 < números <= 100) y mostraré un rectángulo de estrellas de este tamaño</p>
            <b>Ancho:</b><input type="number" name="ancho" id="ancho"><br>
            <b>Alto:</b><input type="number" name="alto" id="alto"><br><br>
            <input type="submit" value="Dibujar" name="dibujar">
            <input type="reset" value="Borrar">
        </form>
    </fieldset>
    <?php
    if (isset($_REQUEST['dibujar']))
    {
        $ancho = $_REQUEST['ancho'];
        $alto = $_REQUEST['alto'];
        print "Ancho: $ancho";
        print "<br>";
        print "Alto: $alto";
        print "<br>";
        for ($i=1; $i<=$alto; $i++)
        {
            for ($j=1; $j<=$ancho; $j++)
            {
                print "*";
            }
            print "<br>";
        }
    }
    ?>
</body>
</html>