<?php
print "<h1>Ejercicio 2</h1>\n";
$numDados = 5;
$suma1 = 0;
$suma2 = 0;
print "<h2>Jugador 1</h2>\n";
for ($i = 0; $i < $numDados; $i++)
{
    $dado = rand(1,6);
    print "<img src='./img/$dado.jpg' width='100' heigh='100'>\n";
    $suma1 += $dado;
}

print "<h2>Jugador 2</h2>\n";
for ($i = 0; $i < $numDados; $i++)
{
    $dado = rand(1,6);
    print "<img src='./img/$dado.jpg' width='100' heigh='100'>\n";
    $suma2 += $dado;
}

print "<h2>Resultado</h2>\n";
if ($suma1 > $suma2)
{
    print "Ha ganado el Jugador 1\n";
}
else
{
    print "Ha ganado el Jugador 2\n";
}
?>